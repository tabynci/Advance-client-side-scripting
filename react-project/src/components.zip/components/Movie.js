import {useState } from 'react'


function Movie(props) {
const [cart, setCart] = useState([])

function handleAddMovies(e, props) {
    e.preventDefault()
    console.log(props)
    var item = {
        movie_name: props.Movie,
        movie_price: props.price
    }
    var movie_arr = [...cart]
    movie_arr.push(item);
    setCart(movie_arr)
    console.log(cart);
  }

  if(props.movie!=="") {
    return (
        <div>
      <span>
       <img src={props.image} width="200px" height="300px"/>
       Movie: {props.Movie}
        <ul>
        
          <li>
            Quantity: 
          </li>
          <li>
            Price: {props.price}
          </li>
        </ul>

      </span>
      <button onClick={function(e) {handleAddMovies(e,props)}}>Add Movies</button>
      </div>
    )
  } 
}
export default Movie;

