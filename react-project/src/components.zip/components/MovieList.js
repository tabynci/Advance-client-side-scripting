import axios from 'axios'
import {useState, useEffect } from 'react';
import Book from './Book'


function MovieList() {
  const [books, setBooks] = useState([]);
  const [title, setTitle] = useState("")
  const [error, setError] = useState("")
  const [author, setAuthor] = useState("")
  const [year, setYear] = useState("")
  const [updateTitle, setUpdateTitle] = useState("")
  const [updateAuthor, setUpdateAuthor] = useState("")
  const [updateYear, setUpdateYear] = useState("")
  const [id, setId] = useState(0)

  const getBooks = async function() {
    try {
      var data = await axios.get("http://localhost:8080")
      var formattedData = data.data.books.map(function(book) {
        return {
          title: book.title,
          id: book.id,
          year: book.year,
          author: book.author,
          isEdit: false
        }
      })
      setBooks(formattedData)
      setError("")
    } catch (e) {
      setError("Unable to fetch books, please try again later")
    }
  }

  useEffect(() => {
   getBooks();
  }, []);

  function handleTitle(e) {
    e.preventDefault()
    setTitle(e.target.value)
  }

  function handleAuthor(e) {
    e.preventDefault()
    setAuthor(e.target.value)
  }

  function handleYear(e) {
    e.preventDefault()
    setYear(e.target.value)
  }

  function handleUpdateTitle(e) {
    e.preventDefault()
    setUpdateTitle(e.target.value)
  }

  function handleUpdateAuthor(e) {
    e.preventDefault()
    setUpdateAuthor(e.target.value)
  }

  function handleUpdateYear(e) {
    e.preventDefault()
    setUpdateYear(e.target.value)
  }

  async function handleSubmit(e) {
    try {
      e.preventDefault()
      await axios.post("http://localhost:8080", {title: title, author:author, year:year})
      await getBooks()
      setTitle("")
      setAuthor("")
      setYear("")
      setError("")
    } catch (e) {
      setError("Unable to create book")
    }
  }

  async function handleDelete(e, id) {
    try {
      e.preventDefault()
      await axios.delete("http://localhost:8080", {data: {book_id: id}})
      await getBooks()
      setError("")
    } catch (e) {
      setError("Unable to delete book")
    }
  }

  function handleEdit(e, id) {
    e.preventDefault()
    var books_arr = [...books]
    var index = books_arr.indexOf(books_arr.find(function(book) {
      return book.id === id
    }))
    books_arr[index].isEdit = true
    setUpdateTitle(books_arr[index].title)
    setUpdateAuthor(books_arr[index].author)
    setUpdateYear(books_arr[index].year)
    setBooks(books_arr)
  }

  async function handleUpdate(e, id) {
    try {
      e.preventDefault()
      await axios.put("http://localhost:8080", {book_id: id, title:updateTitle, author:updateAuthor, year:updateYear})
      await getBooks()
      setUpdateTitle("")
      setUpdateAuthor("")
      setUpdateYear("")
      setError("")
    } catch (e) {
      setError("Unable to update book")
    }
  }

  return (
    <div>
      <h3>Books managing system</h3>
      <label htmlFor="title">Title:</label>
      <input name="title" value={title} onChange={handleTitle} />
      <br/>
      <label htmlFor="author">Author:</label>
      <input name="author" value={author} onChange={handleAuthor} />
      <br/>
      <label htmlFor="year">Year:</label>
      <input name="year" value={year} onChange={handleYear} />
      <br/>
      <button onClick={handleSubmit}>Add Book</button>
      {error ? <h4>{error}</h4> : ""}
      <ul>
        {books.map(function(i, index) {
          if(i.isEdit) {
            return (
              <li key={index}>
                <Book
                  book={books[index]}
                  handleUpdateTitle={handleUpdateTitle}
                  updateTitle={updateTitle}
                  handleUpdateAuthor={handleUpdateAuthor}
                  updateAuthor={updateAuthor}
                  handleUpdateYear={handleUpdateYear}
                  updateYear={updateYear}
                />
                <button onClick={function(e) {
                  handleUpdate(e, i.id)
                }}>
                Update Book
                </button>
              </li>
            )
          } else {
            return (
              <li key={index}>
                <Book book={books[index]}  handleUpdateTitle={handleUpdateTitle} updateTitle={updateTitle} />
                <button onClick={function (e) {
                  handleDelete(e, i.id)
                }}> Delete </button>
                <button onClick={function(e) {
                  handleEdit(e, i.id)
                }}> Update Book</button>
              </li>
            )
          }
        })}
      </ul>
    </div>
  )
}

export default MovieList;
